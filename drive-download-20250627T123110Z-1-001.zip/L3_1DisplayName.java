class Name { 
    public void display() { 
           
    System.out.println("6752300542 Sanucha Sondech"); 
    
    }
 }

public class L3_1DisplayName { 
    public static void main(String[] args) { 
                   
    Name a = new Name();
    a.display();

    } 
}
