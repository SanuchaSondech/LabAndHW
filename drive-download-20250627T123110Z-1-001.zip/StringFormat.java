import java.util.Scanner;

public class StringFormat {
    
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);

        String line = input.nextLine();

        String[] words = line.trim().split("\\s+");
        
        String finalWords = "" ;

        for (int i = 0; i < words.length; i=i+1 ) {
            
            String w = words[i];
            
           if (w.length() > 0) {
                w = w.substring(0,1).toUpperCase() + w.substring(1).toLowerCase();
            }
            
            finalWords = finalWords + w;
            
            if (i < words.length - 1) {
                finalWords = finalWords + " ";
            }
        }
        
        System.out.println(finalWords);
    }
}